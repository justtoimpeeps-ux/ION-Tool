# ION Orinda Campus Planner

A browser factory-design and logistics tool for the IE-4 engine program. This version uses the supplied consolidated register and the user's campus clarification: upstream Factory A/B works, with shared receiving, subassembly, precision machining, and final assembly/test buildings. **247 engines per normal nine-hour day is the current A+B operating reference, not a fleet-sizing target.**

The downloadable `ION_Campus_Planner_v2.html` is self-contained: open it in a modern desktop browser, with no installation or network access. The source ZIP also includes the register and development files.

To serve the source project, no application packages, credentials or backend are required:

```sh
python3 -m http.server 8000
# alternatively: npm start
```

Open the served page in a browser. Python's static server is for development, not a production deployment.

## What is included

- All 934 fixed workstations from §7A, relocated without duplicating assets. Original A/B ownership remains attached. The 160 mobile material movers are referenced separately.
- Exact eight-subassembly material and purchased-component recipes from §§8C/11, with proper kg/each units. The complete kit passes through machining, final assembly, calibration, certification and packaging as in §12.
- Equipment-first floor generation at 2 × 2 m per cell. Registered counts are fixed; the footprint follows placement and aisles. Layouts, process allocations within categories and footprints are estimates.
- Belt, cart and walking routes in that efficiency order. Coloured material lanes separate shared-path flows, with duplicate lines aggregated and a material colour key. Building input/output access points and receiving bins participate in the same constrained flow calculation as internal routes.
- Tile recipe amounts, production figures, worker skill colours, port markers and detailed hover information. Inspect a station for full inputs, worker assignments and industrial upgrade options.
- In Inspect mode, click to inspect or drag equipment, storage and transport tiles directly (Move mode remains available). Dropping a path onto another path swaps them. Building access points stay fixed. Paint paths by dragging, rotate belts/equipment, and create storage by dragging a rectangle. Changes accumulate credit/time estimates and can be undone.
- Separate current operating reference and candidate simulation forecast. Test a nine-hour day or an overtime scenario without advancing campaign time or worker experience.
- Tooling/quick-change fixture and robotic loading/inspection upgrade scenarios, plus the original condition refit. Costs, installation times and performance assumptions are visible before applying.
- Campus, building and rectangular-area JSON export/import for collaboration. Imports validate the complete merged plan before confirmation. Area imports retain coordinates and preserve everything outside the rectangle. A region cutting through equipment is rejected. Scoped cost/time quotes merge by work ID without charging the same shared quote twice. Only campus imports replace resource scenarios and the complete implementation ledger.
- Automatic browser saves and portable JSON downloads. Legacy plans remain in their old browser key and can be downloaded, but incompatible old recipes are not silently migrated.

## Source facts and model limits

Read [register reconciliation](docs/REGISTER_RECONCILIATION.md) for counts, recipes, stage caps, user decisions and unresolved details. The original [DOCX](docs/sources/ION_Consolidated_Assets_Register.docx) and a [text extraction](docs/sources/ION_Consolidated_Assets_Register.txt) are retained.

The register does not validate individual machine cycles, yields, uptime, task assignments, stock counts or exact footprints. Candidate rates distribute its provisional annual stage model over assigned stations using 365 nine-hour operating days, level-2 staffing and 95% condition. The annual calendar remains unverified. The untouched register layout reaches approximately 245.6 certified engines/day after model warm-up, consistent with the rounded 247/day reference. Its cold-start first day is approximately 144.0 because no real WIP is invented. Forecasts can differ after planning changes; the program never replaces the known 247/day fact with its forecast.

The solver reports a nine-hour day in 36 planning steps. Its default warmed mode first calculates two synthetic startup days, carrying only model buffers and stock into the measured day. A cold-start mode begins directly from empty buffers. Warm-up does not advance campaign time, experience, or any real inventory ledger. The solver uses complete-recipe reservation, finite machine buffers, finite storage, cargo-volume limits and efficiency-weighted routing. Nearby local sources are preferred. It is a greedy planning model, not a global optimization solver or an animation of individual items and travel times. Zero stock is an explicit scenario starting point, not a claim that current warehouses are empty. The unresolved ~750 WIP is not invented at any particular stage. No Factory C output is added.

Prices, industrial upgrade performance, workforce skill distribution, handling volumes, aisle dimensions and overtime wage estimates are labeled assumptions. Labour assignments are proposed operators rather than a verified employee roster. Construction completion and experience advancement require campaign decisions outside Test Campus.

## Development

- `js/register.js`: source equipment inventories, staffing references, exact BOM totals and candidate stage caps.
- `js/data.js`: materials, process recipes, campus assignment rules, provisional station rates and upgrade catalogue.
- `js/baseline.js`: inventory-preserving placement and derived floor dimensions.
- `js/engine.js`: production and physical transport calculation.
- `js/app.js`: editing, rendering, scenario and blueprint persistence.

Keep IDs stable when revising data and add an explicit schema migration before changing saved-plan meaning. New blueprints use `ION-campus-2`.

## Validation

```sh
npm test
# Individual case output:
node tests/engine.test.cjs
node tests/baseline.test.cjs
node tests/campus-engine.test.cjs
```

The twenty-two regression cases cover source reconciliation, complete recipes, units, category counts and ownership, placement and port access, repeatability, finite stock/buffers, transport limits, receiving routes, disconnections, overtime, upgrades, and reporting a single measured day after model warm-up.

Browser checks require Playwright and Chromium, supplied in this cloud environment:

```sh
node tests/browser.cjs http://127.0.0.1:8000
node tests/standalone.cjs http://127.0.0.1:8000/dist/ION_Campus_Planner_v2.html
```

Set `CHROMIUM_PATH` if needed. Browser tests exercise actual pointer editing under zoom, forecasts, upgrades/undo, selected-area import preservation, atomic rejection, full-campus round-trip and local restoration. Large campus simulations can take several seconds; they are planning calculations, not continuous real-time gameplay.

## Package a review version

`npm run package` creates `dist/ION_Campus_Planner_v2.html` and the complete source ZIP. The HTML embeds its styles, data, simulation worker and source notes; no server is needed. The editor computes in a background worker where supported, with a main-thread fallback. Editing during a calculation discards that now-stale forecast.

The managed cloud browser blocks `file://` navigation. Standalone validation here serves that single HTML document locally and verifies no separate scripts, styles, or external resources load. Direct-file launch is intended for a normal desktop browser but cannot be verified through this cloud browser policy.

## Interactive controls update

Save, scope selection, export/import and Workforce are on the top bar. Inspect mode supports direct dragging of equipment, storage and explicit transport tiles; drive lanes are empty space for equipment placement and are removed beneath a moved footprint. All otherwise unoccupied floor is walkable by default. Building access squares remain fixed.

Material routes use separated colour lanes with duplicate per-material edges combined. Each station tile shows its type/number, current/candidate-nameplate output and every input’s per-cycle quantity plus delivered/required quantity per selected day. Daily need is at candidate nameplate, not a claim that those deliveries occurred. Input and output colours are on the station edges; flexible stations show both on every edge.

The new baseline uses varied editable staffing requirements by equipment type, rather than assuming two operators everywhere. The planning roster has 1,203 assigned and 2,047 unassigned people within the 3,250 source headcount (A+B operations plus shared QA/safety). Unassigned in this model does not mean those staff are genuinely idle: handling, shift support and safety roles still have other duties. T0–T5 skill distribution is an explicit assumption (5%, 30%, 35%, 22%, 6%, 2%, mean tier 2), not a register census. Required staffing and worker skills can be edited as scenario/roster corrections without implying training or elapsed campaign time. Assigning and releasing workers transfers existing identities to/from compatible-role pools; it does not create new employees. Undo, campus saves and scoped imports retain roster state.
