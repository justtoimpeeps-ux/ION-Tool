// Exact manufacturing inputs: register §§8C and 11. Masses are kg; modules are each.
// Footprints, volumes, staffing factors and prices remain provisional planning values.
const MATERIALS={
 iron:{title:'Iron alloy',unit:'kg',volume:.00013},nickel:{title:'Nickel alloy',unit:'kg',volume:.00012},cobalt:{title:'Cobalt alloy',unit:'kg',volume:.00012},chromium:{title:'Chromium alloy',unit:'kg',volume:.00014},copper:{title:'Copper',unit:'kg',volume:.00012},silver:{title:'Silver',unit:'kg',volume:.0001},gold:{title:'Gold',unit:'kg',volume:.00006},pgm:{title:'Platinum-group metals',unit:'kg',volume:.00006},
 superconductor:{title:'Superconductive media',unit:'kg',volume:.001},ceramic:{title:'Technical ceramic',unit:'kg',volume:.0004},tibanna:{title:'Tibanna charge',unit:'kg',volume:.005},electronicsFeed:{title:'Electronics feedstock',unit:'kg',volume:.002},coolant:{title:'Coolant charge',unit:'kg',volume:.001},
 fieldCoil:{title:'Precision field coils',unit:'each',volume:.01},regulator:{title:'Regulator modules',unit:'each',volume:.01},seal:{title:'Seals',unit:'each',volume:.001},processor:{title:'Processor modules',unit:'each',volume:.002},coupler:{title:'Interface couplers',unit:'each',volume:.005},sensorModule:{title:'Sensor modules',unit:'each',volume:.003},safingModule:{title:'Safing modules',unit:'each',volume:.003},
 housingRaw:{title:'Formed housing preform',unit:'each',volume:1.4},housingHeat:{title:'Heat-processed housing',unit:'each',volume:1.3},housing:{title:'Structural core housing',unit:'each',volume:1.2},field:{title:'Field-control set',unit:'each',volume:.6},energy:{title:'Energy-transfer set',unit:'each',volume:.6},gas:{title:'Gas-control set',unit:'each',volume:.5},electronic:{title:'Control-electronics set',unit:'each',volume:.25},thermal:{title:'Thermal set',unit:'each',volume:.6},interface:{title:'Precision-interface set',unit:'each',volume:.25},sensor:{title:'Sensor/safety set',unit:'each',volume:.25},kit:{title:'Complete eight-subassembly IE-4 kit',unit:'each',volume:3.5},machined:{title:'Machined/integrated core',unit:'each',volume:4.4},core:{title:'Assembled core',unit:'each',volume:4.4},calibrated:{title:'Calibrated core',unit:'each',volume:4.4},tested:{title:'Certified IE-4 core',unit:'each',volume:4.4},shipped:{title:'Dispatched IE-4 core',unit:'each',volume:4.4}
};
const SPECS={
 cast:{name:'Casting / forging / forming cell',building:'Foundry',category:'casting',stage:'casting',w:3,h:3,inputs:{iron:182,nickel:46,chromium:14},outputs:{housingRaw:1},price:93000,days:8,workers:2,port:'fixed',color:'#9a765d'},
 heat:{name:'Heat treatment / vacuum processing unit',building:'Heat Treatment',category:'heat',stage:'casting',w:3,h:3,inputs:{housingRaw:1},outputs:{housingHeat:1},price:120000,days:10,workers:2,port:'fixed',color:'#a27359'},
 finish:{name:'Surface finishing / cleaning / coating line',building:'Finishing',category:'finishing',stage:'casting',w:3,h:3,inputs:{housingHeat:1},outputs:{housing:1},price:118000,days:9,workers:2,port:'fixed',color:'#8b8e5c'},
 field:{name:'Field-control assembly cell',building:'Assembly',category:'assembly',stage:'components',w:3,h:3,inputs:{nickel:18,cobalt:7,copper:1.8,silver:.4,gold:.15,pgm:.05,superconductor:38,fieldCoil:12},outputs:{field:1},price:92000,days:7,workers:2,port:'flex',color:'#698c95'},
 energy:{name:'Energy-transfer assembly cell',building:'Assembly',category:'assembly',stage:'components',w:3,h:3,inputs:{nickel:12,copper:4,silver:.6,gold:.3,pgm:.1,superconductor:21,ceramic:34},outputs:{energy:1},price:94000,days:7,workers:2,port:'flex',color:'#698c95'},
 gas:{name:'Gas-control assembly cell',building:'Assembly',category:'assembly',stage:'components',w:3,h:3,inputs:{iron:12,nickel:9,chromium:4,tibanna:16,regulator:6,seal:18},outputs:{gas:1},price:78000,days:6,workers:2,port:'flex',color:'#698c95'},
 electronic:{name:'Control-electronics integration bench',building:'Assembly',category:'assembly',stage:'components',w:3,h:2,inputs:{copper:1.2,silver:.3,gold:.2,pgm:.1,electronicsFeed:24,processor:4},outputs:{electronic:1},price:83000,days:5,workers:2,port:'flex',color:'#698c95'},
 thermal:{name:'Thermal-management assembly cell',building:'Assembly',category:'assembly',stage:'components',w:3,h:3,inputs:{nickel:17,cobalt:3,chromium:6,ceramic:41,coolant:28},outputs:{thermal:1},price:92000,days:6,workers:2,port:'flex',color:'#698c95'},
 interface:{name:'Precision-interface fit-up bench',building:'Assembly',category:'assembly',stage:'components',w:3,h:2,inputs:{nickel:16,iron:9,chromium:3,coupler:8},outputs:{interface:1},price:61000,days:5,workers:2,port:'flex',color:'#698c95'},
 sensor:{name:'Sensor and safety integration bench',building:'Assembly',category:'assembly',stage:'components',w:3,h:2,inputs:{copper:.5,silver:.2,gold:.07,pgm:.03,electronicsFeed:13,sensorModule:10,safingModule:2},outputs:{sensor:1},price:67000,days:5,workers:2,port:'flex',color:'#698c95'},
 kit:{name:'Eight-subassembly kitting station',building:'Assembly',category:'assembly',stage:'receiving',w:3,h:3,inputs:{housing:1,field:1,energy:1,gas:1,electronic:1,thermal:1,interface:1,sensor:1},outputs:{kit:1},price:89000,days:6,workers:2,port:'flex',color:'#548877'},
 cnc:{name:'Precision machining / integration centre',building:'Machining',category:'machining',stage:'machining',w:3,h:3,inputs:{kit:1},outputs:{machined:1},price:155000,days:10,workers:2,port:'flex',color:'#527fa8'},
 integrate:{name:'Final engine assembly / integration cell',building:'Assembly',category:'assembly',stage:'integration',w:4,h:3,inputs:{machined:1},outputs:{core:1},price:142000,days:9,workers:3,port:'fixed',color:'#668477'},
 calibrate:{name:'Calibration / functional test stand',building:'Testing',category:'test',stage:'calibration',w:4,h:4,inputs:{core:1},outputs:{calibrated:1},price:190000,days:12,workers:3,port:'fixed',color:'#927b9f'},
 qa:{name:'QA / certification acceptance stand',building:'Testing',category:'test',stage:'qa',w:4,h:4,inputs:{calibrated:1},outputs:{tested:1},price:210000,days:13,workers:3,port:'fixed',color:'#997b9f'},
 package:{name:'Robotic packaging / palletizing station',building:'Packaging',category:'packaging',stage:'dispatch',w:3,h:3,inputs:{tested:1},outputs:{shipped:1},price:80000,days:6,workers:2,port:'flex',color:'#7d8461'},
 support:{name:'Fabrication / toolroom / maintenance workstation',building:'Maintenance',category:'toolroom',stage:null,w:3,h:3,inputs:{},outputs:{},rate:0,price:72000,days:6,workers:2,port:'flex',color:'#647083',support:true}
};
// Explicit candidate calibration, not measured machine rates. Each §13 A+B cap is
// shared across both factories' assigned stations at level-2 staffing / 95% condition.
// This derives rates from the register's existing stage model, NEVER fleet size from 247/day.
for(const [type,s]of Object.entries(SPECS))if(s.stage){
 const count=Object.values(ION_REGISTER.allocation).reduce((n,a)=>n+(a[type]||0),0);
 s.rate=ION_REGISTER.stages[s.stage]/(365*count*.7505);
 s.rateSource='§13 candidate stage model, evenly distributed across provisionally assigned A+B stations';
}
// The four shared production buildings and two upstream works are the user's campus allocation.
for(const s of Object.values(SPECS)){
 if(['cast','heat','finish','support'].some(t=>SPECS[t]===s))s.building=null;
 else if(s.category==='machining')s.building='Precision Machining';
 else if(s.category==='assembly'&&s.stage!=='integration')s.building='Subassemblies';
 else s.building='Final Assembly & Test';
}
const BLDGS=['Receiving','Factory A','Factory B','Subassemblies','Precision Machining','Final Assembly & Test'];
const UPGRADES={
 tooling:{name:'Precision tooling & quick-change fixtures',description:'Improved fixtures and reduced changeover time.',speed:1.15,priceFraction:.12,days:4},
 automation:{name:'Robotic loading & inspection assist',description:'Automated handling raises capacity; one fewer operator is needed, minimum one.',speed:1.25,workerReduction:1,priceFraction:.4,days:8}
};
// Work-centre staffing and individual skill distribution are planning assumptions.
const DEFAULT_STAFFING={cast:2,heat:1,finish:1,field:2,energy:2,gas:1,electronic:1,thermal:2,interface:1,sensor:1,kit:1,cnc:1,integrate:3,calibrate:2,qa:2,package:1,support:1};
const STAFF_ROLES={machining:'Machining / upstream',assembly:'Assembly',handling:'Materials handling',shiftSupport:'Shift support / toolroom',qa:'QA / safety'};
const roleForSpec=s=>s.category==='test'?'qa':s.category==='assembly'?'assembly':s.category==='packaging'?'handling':s.category==='toolroom'?'shiftSupport':'machining';
const STAFF_POOLS=Object.entries(ION_REGISTER.factories).flatMap(([origin,f])=>Object.entries(f.roles).map(([role,count])=>({id:role+'-'+origin.slice(-1),origin,role,count}))).concat([{id:'qa-shared',origin:'Shared QA / safety',role:'qa',count:300}]);
// A transparent, editable model distribution, not an asserted employee census.
// 5% T0, 30% T1, 35% T2, 22% T3, 6% T4, 2% T5; mean tier 2.
const planningTier=i=>{const n=(i*37)%100;return n<5?0:n<35?1:n<70?2:n<92?3:n<98?4:5};
