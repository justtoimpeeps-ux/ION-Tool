/* Source facts are reference data. Register process caps are explicitly modeled,
   not independently measured per-station cycles. User confirms 247/day is A+B. */
const ION_REGISTER={
  source:'ION Consolidated Assets Register, uploaded organization update 2026-10-13; document header Working V2, 12 October 2026',
  observed:{enginesPerDay:247,scope:'A+B combined',source:'User clarification'},
  sustainable:{enginesPerYear:90000,scope:'A+B combined',source:'§13; modeled sustainable reference'},
  factories:{
    'Factory A':{operations:1500,roles:{machining:550,assembly:420,handling:210,shiftSupport:320},counts:{machining:155,casting:35,heat:44,assembly:88,test:42,finishing:31,packaging:18,toolroom:65,movers:80}},
    'Factory B':{operations:1450,roles:{machining:530,assembly:405,handling:205,shiftSupport:310},counts:{machining:145,casting:33,heat:42,assembly:84,test:40,finishing:29,packaging:18,toolroom:65,movers:80}}
  },
  categories:{machining:'Precision machining / mill-turn',casting:'Casting / forging / forming',heat:'Heat treatment / vacuum processing',assembly:'Robotic assembly / integration',test:'Test / calibration / acceptance',finishing:'Surface finishing / cleaning / coating',packaging:'Packaging / palletizing',toolroom:'Fabrication / toolroom / maintenance',movers:'Mobile material-handling units'},
  // Provisional task allocation WITHIN the documented categories; never extra assets.
  allocation:{
    'Factory A':{cast:35,heat:44,finish:31,cnc:155,field:10,energy:10,gas:8,electronic:8,thermal:10,interface:7,sensor:7,kit:12,integrate:16,calibrate:20,qa:22,package:18,support:65},
    'Factory B':{cast:33,heat:42,finish:29,cnc:145,field:9,energy:9,gas:8,electronic:8,thermal:9,interface:7,sensor:7,kit:12,integrate:15,calibrate:19,qa:21,package:18,support:65}
  },
  // A+B candidate stage capacities in engine equivalents/year (§13).
  stages:{receiving:112000,casting:105000,machining:96000,components:100000,integration:94000,calibration:92000,qa:90000,dispatch:110000},
  masses:{iron:203,nickel:118,cobalt:10,chromium:27,copper:7.5,silver:1.5,gold:.72,pgm:.28,superconductor:59,ceramic:75,tibanna:16,electronicsFeed:37,coolant:28},
  purchased:{fieldCoil:12,regulator:6,seal:18,processor:4,coupler:8,sensorModule:10,safingModule:2},
  opening:{certifiedEngines:0,wipApprox:750,wipScope:'A+B, stage counts unreconciled',rawStock:null,subassemblyStock:null},
  sharedPersonnel:{engineering:420,testingQA:300,supplyLogistics:250,facilities:220,corporate:160},
  unresolved:['Per-work-centre cycles, yields and uptime','Subassembly counted stock','Raw stock balances','Exact task allocations within equipment categories','Factory-specific realized output split','Validated footprints and upgrade costs']
};
if(typeof module!=='undefined')module.exports=ION_REGISTER;
