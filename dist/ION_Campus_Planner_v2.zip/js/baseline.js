/* Registered fleets are fixed; physical allocation follows the user's campus plan.
   Floor dimensions are derived AFTER placing assets, receiving stores and aisles. */
const FactoryBaseline=(()=>{
 function billOfMaterials(specs,units=1){
  const demand={shipped:units},cycles={};
  for(const type of FactoryEngine.topological(specs).slice().reverse()){
   const sp=specs[type],n=Math.max(0,...Object.entries(sp.outputs).map(([item,q])=>(demand[item]||0)/q));cycles[type]=n;
   for(const [item,q]of Object.entries(sp.inputs))demand[item]=(demand[item]||0)+q*n;
  }
  const outputs=new Set(Object.values(specs).flatMap(s=>Object.keys(s.outputs)));
  return {demand,cycles,raw:Object.fromEntries(Object.entries(demand).filter(([k])=>!outputs.has(k)))};
 }
 function generate(specs,materials,names){
  const buildings=Object.fromEntries(names.map(name=>[name,{machines:[],storage:[],paths:[],docks:{input:[],output:[]},revision:2,layoutRevision:3}]));
  const perCore=billOfMaterials(specs),incoming=Object.fromEntries(Object.entries(perCore.raw).map(([k,v])=>[k,Math.ceil(v*247*1.1)]));
  let worker=0;
  for(const [owner,allocation]of Object.entries(ION_REGISTER.allocation))for(const [type,count]of Object.entries(allocation)){
   const sp=specs[type],destination=sp.building||owner,role=roleForSpec(sp),homePool=role==='qa'?'qa-shared':role+'-'+owner.slice(-1),staffingRequired=DEFAULT_STAFFING[type]??sp.workers;
   for(let i=0;i<count;i++)buildings[destination].machines.push({id:owner.replace(' ','')+'-'+type+'-'+(i+1),type,owner,number:i+1,x:0,y:0,w:sp.w,h:sp.h,angle:0,condition:.95,staffingRequired,upgrades:[],crew:Array.from({length:staffingRequired},()=>({id:'worker-'+(++worker),level:planningTier(worker),role,homePool}))});
  }
  // Planning deliveries, not a claim about unresolved opening stock.
  for(const item of Object.keys(incoming))buildings.Receiving.storage.push({id:'receiving-'+item,item,stock:0,x:0,y:0,w:2,h:2,receiving:true});
  for(const [name,b]of Object.entries(buildings)){
   const rows=[];
   if(name==='Receiving')for(let i=0;i<b.storage.length;i+=5)rows.push(b.storage.slice(i,i+5));
   else if(name==='Final Assembly & Test'||name==='Subassemblies'){
    // Parallel production bays avoid sending the entire plant through one common aisle.
    const types=FactoryEngine.topological(specs).filter(t=>b.machines.some(m=>m.type===t));
    const bays=name==='Final Assembly & Test'?b.machines.filter(m=>m.type==='integrate').length:Math.min(...types.filter(t=>t!=='kit').map(t=>b.machines.filter(m=>m.type===t).length));
    for(let row=0;row<bays;row++){
     const items=[];
     for(const type of types){const group=b.machines.filter(m=>m.type===type),start=Math.floor(row*group.length/bays),end=Math.floor((row+1)*group.length/bays);items.push(...group.slice(start,end))}
     if(items.length)rows.push(items);
    }
   }else for(const type of FactoryEngine.topological(specs)){
    const group=b.machines.filter(m=>m.type===type);
    // Short process rows, not a preselected building envelope.
    const across=Math.min(10,Math.max(1,Math.ceil(Math.sqrt(group.length))));
    for(let i=0;i<group.length;i+=across)rows.push(group.slice(i,i+across));
   }
   let y=2,maxX=0;const aisles=[];
   for(const row of rows){let x=2;const height=Math.max(...row.map(o=>o.h));for(const o of row){o.x=x;o.y=y;x+=o.w+2;maxX=Math.max(maxX,o.x+o.w)}aisles.push({top:y,y:y+height});y+=height+4;}
   b.cols=Math.max(16,maxX+3);b.rows=Math.max(12,y);
   const occupied=new Set();for(const o of [...b.machines,...b.storage])for(let yy=o.y;yy<o.y+o.h;yy++)for(let xx=o.x;xx<o.x+o.w;xx++)occupied.add(xx+','+yy);
   const paths=new Map();
   const add=(x,y,kind='cart')=>{const k=x+','+y;if(!occupied.has(k)&&x>=0&&y>=0&&x<b.cols&&y<b.rows&&(!paths.has(k)||kind==='cart'))paths.set(k,{x,y,kind,cargo:null,dir:0})};
   for(const a of aisles){for(let x=1;x<b.cols-1;x++){add(x,a.y);add(x,a.y+1);add(x,a.y+2,'walk')}
    // Input/output access at both ends, serving all rows without a single artificial choke.
    b.docks.input.push([1,a.y],[b.cols-2,a.y]);b.docks.output.push([1,a.y+1],[b.cols-2,a.y+1]);
   }
   for(const o of [...b.machines,...b.storage]){const a=aisles.find(a=>a.top===o.y);for(let yy=o.y;yy<=a.y+1;yy++){add(o.x-1,yy);add(o.x+o.w,yy)}}
   // Continue permanently clear service gaps between departments. Aisles are
   // not forced to funnel the whole factory through only its two perimeter edges.
   for(let xx=1;xx<b.cols-1;xx++){
    let clear=true;for(let yy=1;yy<b.rows-1;yy++)if(occupied.has(xx+','+yy)){clear=false;break}
    if(clear)for(let yy=1;yy<b.rows-1;yy++)add(xx,yy);
   }
   b.paths=[...paths.values()];
  }
  return {buildings,workerPool:availableWorkers(buildings,specs),sizing:{observed:247,perCore:perCore.raw,incoming,dockCapacity:2000}};
 }
 function availableWorkers(buildings,specs){
  const used={};for(const b of Object.values(buildings))for(const m of b.machines)for(const w of m.crew){const role=w.role||roleForSpec(specs[m.type]),pool=w.homePool||(role==='qa'?'qa-shared':role+'-'+(m.owner==='Factory B'?'B':'A'));used[pool]=(used[pool]||0)+1}
  const ids=new Set(Object.values(buildings).flatMap(b=>b.machines.flatMap(m=>m.crew.map(w=>w.id))));let index=0;return STAFF_POOLS.flatMap(pool=>{let sequence=0;return Array.from({length:Math.max(0,pool.count-(used[pool.id]||0))},()=>{let id;do{id='reserve-'+pool.id+'-'+(++sequence)}while(ids.has(id));ids.add(id);return {id,level:planningTier(++index),role:pool.role,homePool:pool.id}})});
 }
 return {generate,billOfMaterials,availableWorkers};
})();
if(typeof module!=='undefined')module.exports=FactoryBaseline;
