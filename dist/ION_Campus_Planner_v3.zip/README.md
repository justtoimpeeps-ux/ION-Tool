# ION Orinda Campus Planner V3

A browser factory planning tool for the IE-4 engine program. The current operating reference is **247 engines/day across A+B**, in a nine-hour production day. It is not a target used to choose machine counts.

Open `ION_Campus_Planner_v3.html` from the downloadable ZIP in a desktop browser. It is self-contained and needs no server or network. To run the source, use `npm start` or `python3 -m http.server 8000`.

## Layout and controls

Start with the Orinda campus schematic, then select a building: Receiving, Factory A, Factory B, Subassemblies, Precision Machining, or Final Assembly & Test. All 934 registered fixed assets are placed once, retaining original ownership. The two factories contain the upstream processes; shared halls contain their assigned downstream operations. Floor dimensions follow equipment placement, with 2 × 2 m squares and estimated industrial working envelopes.

Click and drag tiles directly. Hover for recipes, staffing, assumptions and detailed output. Double-click a tile or select Tile actions to edit workers, stock or upgrades. Tiles show centered type/number and current/max production, plus worker colors and input/output edges. Original SVG equipment illustrations distinguish equipment families.

Use **B** or the side Build palette to select machines, paths, storage or areas. Hover catalogue items for recipe, staffing, cost, implementation time and capacity. **R** rotates the selected tile or placement; **Esc** returns to normal interaction. Expand a floor at any edge through the palette. All unoccupied squares are walkable; explicit drive lanes remain empty space for moving equipment.

Flow controls show separated material lanes connected to tile edges, enlarged start/end arrows and material/rate hover details. The Implementation Plan tracks estimated costs and time. The right side retains the production dashboard and interbuilding cargo flow; troubleshooting Diagnostics is collapsed at the bottom. Source and assumptions remain in the documentation instead of a permanent panel.

Save, scope, JSON export/import, Undo and Workforce are on the top bar. Campus, building and rectangular-area exports support collaboration; scoped imports preserve unaffected tiles and reconcile worker identities and implementation quotes. Browser saves are automatic. Old incompatible saves are retained for download rather than silently migrated.

## Production and workforce model

The active sources are the November 9 assets register and logistics document in `docs/sources/110926/`. See [register reconciliation](docs/REGISTER_RECONCILIATION.md) for detailed facts and assumptions. Internal coil, regulator, seal and coupler chains are represented, alongside all eight parent subassemblies and downstream kit, machining, integration, calibration, QA and dispatch steps. Expanded recipes conserve the documented material budgets. Missing insulation/seal feed and regulator bought-part quantities are explicitly provisional.

Machine counts come from the registered inventory. Process assignments within those counts are planning estimates. Candidate rates divide each annual stage capacity across its assigned machines, using a provisional 365-day calendar, nine-hour day, Tier 2 staffing and 95% condition reference. They are **not measured machine cycle times**. Workforce, condition, upgrades, materials and transport modify those rates. Test Campus does not advance campaign time.

The modeled 3,250-person roster uses the user's proposed Tier 1–5 distribution: 38%, 38%, 19%, 4.5%, 0.5%, rounded to 1,235 / 1,235 / 618 / 146 / 16. Each employee has a persistent identity, role, pool and editable skill level. Assignment/release transfers existing people. Unassigned does not mean verified idle: other duties are not fully modeled. Automatic experience and promotions are not implemented. Staffing requirements vary by equipment and remain estimates.

Condition starts at an explicitly assumed 95%; it is not a measured inspection result. Thirteen confirmed opening stocks are converted from tonnes to kg once. Unknown WIP stage allocation is not invented. Additional incoming supplies are planning assumptions, not authorized shipments.

The current aggregate solver calculates one day in 36 steps with finite buffers, complete-recipe reservations and volume-weighted routing. There is no UI warm-up selector or shared cargo proxy cap. Individual vehicle travel, collision avoidance, preshift preparation, maintenance and animated workers are the next layer described in [transport replay design](docs/TRANSPORT_REPLAY_DESIGN.md). This version does not yet animate those operations or persist a campaign inventory ledger.

## Development and validation

`js/register.js` holds source inventories and caps; `js/data.js` recipes, equipment and assumptions; `js/baseline.js` the initial layouts; `js/engine.js` production and routing; `js/art.js` illustrations; `js/app.js` browser interaction. New blueprints use `ION-campus-3`.

```sh
npm test
node tests/ui-v3.cjs http://127.0.0.1:8000
npm run package
node tests/standalone.cjs http://127.0.0.1:8000/dist/ION_Campus_Planner_v3.html
```

Browser tests require Playwright and Chromium (`CHROMIUM_PATH` may override the executable). The current V3 browser suite checks campus navigation, compact panels, palette shortcuts, overlay dragging, rotation, floor expansion/Undo, material hover and scoped import. Older browser scripts document earlier interfaces and are not the V3 validation entry point. Unit checks cover source reconciliation, recipes, equipment ownership, placement, roster conservation, finite stock, routing and stage rates.

Packaging creates the standalone HTML and a complete source ZIP. The managed cloud browser blocks direct `file://` navigation, so automated standalone checks serve that single file locally and verify it loads no external dependencies. A normal desktop file launch remains outside that cloud-browser check.
