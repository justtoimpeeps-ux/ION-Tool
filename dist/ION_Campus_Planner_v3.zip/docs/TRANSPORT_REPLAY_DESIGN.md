# Agreed transport/day replay specification

This is a design record, not a claim that vehicle traffic or animated maintenance is implemented.

## Cycle

1. Start with the previous day's actual modeled closing stock and condition, not a fresh inventory reset.
2. Compare each tile's buffers with configured staging targets. Create tasks only for missing material and required maintenance.
3. Simulate a separately tracked pre-shift logistics/maintenance phase. It takes as long as its tasks require. Workers begin early enough; concurrent work is constrained by qualified crews, access, carriers, traffic, parts and tools. Labour, overtime, energy and consumable costs accrue.
4. Run nine production hours, replenishing tiles as required. Production waits for complete recipes; full output buffers can block machines.
5. Preserve all leftovers, WIP and finished output. Record net consumption and shipment, not disappearance. Warehouse balances change even if every tile is restaged to the same starting target each day.
6. Replay the recorded events with fixed starting snapshot/seed. Replay restores that snapshot; Continue Next Day carries ending balances. Seeking and playback speed do not alter results or campaign time.

The prepared state is repeatable at tile level. Global warehouse totals are not identical after a productive day unless actual replenishment balances consumption.

## Physical transport

- Derive load capacity from usable volume, payload mass, dimensions/packing limits and load-centre/shape constraints. Do not infer payload solely from a machine's floor footprint.
- Raw feeds have known kg quantities; module masses, packing and item envelopes need documented assumptions. The current volume figures are planning allowances, not validated packing studies.
- Respect the source fleet counts: 160 mobile movers and 110 combined forklifts/pallet movers. Type splits, payload ratings, speeds and loading times are not specified by the register.
- Use reserved squares/time slots, no head-on swaps, multi-square carrier footprints and turning/loading clearance. Wait/yield at conflicts, reroute when practical, and report deadlocks rather than teleporting cargo.
- Every pickup decreases real stock. Carried cargo counts as in-transit inventory. Every drop increases a specific buffer. Failed or waiting tasks cannot create deliveries.
- Plant-to-plant routes and supplier arrivals remain separate from actual Logistics dispatch orders. A replay does not issue an external voyage or invent an approved cargo shipment.

## People and maintenance

- Workers use job-specific clothing; hat/helmet colour uses the existing T0–T5 legend.
- A worker can perform only one task at a time. Prep staffing is drawn from qualified existing pools or explicit planned hires, not duplicated employees.
- Maintenance consumes assigned staff time, access, parts and tools and restores an explicit condition target, capped at 100%. No free condition reset or earned experience is implied.
- Current 95% condition and staffing/skill distributions are assumptions. Wear functions, failure probabilities, qualification rules and maintenance service times need explicit model parameters before becoming behavior.

## Implementation direction

Calculate in a background event-driven simulation, then render a basic top-down replay. Store initial state, deliveries, pickups/drops, reserved movements, work start/end, waits, condition changes and final ledger. Traffic and inventory must drive production; the replay is a view of those events. Reuse per-operation batch data and tile artwork as future sprite frames. Validate conservation, deterministic playback, concurrency and no-overlap traffic before treating the replay as a throughput forecast.
