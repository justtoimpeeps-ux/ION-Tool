/* Persistent, deterministic operating days. All transport/service parameters are
   editable planning assumptions; no measured cycle times are asserted. */
const FactoryDay=(()=>{
 const EPS=1e-7,copy=x=>structuredClone(x),sum=o=>Object.values(o).reduce((a,b)=>a+b,0);
 const DEFAULTS={hours:9,bufferMinutes:60,openingWip:750,phaseOpeningWork:1,forklifts:110,tugs:160,walkers:12,maintenanceTarget:.97,serviceTrigger:.01,payUnassigned:1,overtimeMultiplier:1.5,maintenanceParts:1000,wearPerDay:.002,serviceMinutes:10,serviceMinutesPerPoint:3,wage:25,maintenanceWage:35,energyPerVehicleHour:4,partCost:30,kitsInbound:0,tickSeconds:60,doorSeconds:2,dispatchLookaheadMinutes:15,beltSpeed:.8,beltVolumePerMetre:.25};
 const VEHICLES={tug:{name:'Electric tow tractor',volume:12,payload:4000,deck:[4,2,2.4],length:2,speed:2,loadSeconds:45},forklift:{name:'Electric forklift',volume:6,payload:2000,deck:[2.4,1.8,2.2],length:2,speed:1.4,loadSeconds:40},walker:{name:'Hand cart / walking handler',volume:.35,payload:100,deck:[1.2,.8,1],length:1,speed:1,loadSeconds:20}};
 function settings(raw={}){const {promotionHours:ignoredLegacyProgression,...input}=raw;const c={...DEFAULTS,...input};for(const k of Object.keys(DEFAULTS)){if(!Number.isFinite(c[k])||c[k]<0)throw Error('Invalid day setting: '+k)}if(!c.beltSpeed||!c.beltVolumePerMetre)throw Error('Belt speed and carrying volume must be positive.');if(c.hours<1||c.hours>24||c.bufferMinutes<5||c.bufferMinutes>240||c.openingWip>900||c.forklifts>110||c.tugs>160||c.walkers>100||c.maintenanceTarget>1||c.wearPerDay>.1||c.tickSeconds<10||c.tickSeconds>300)throw Error('Day settings exceed supported planning limits.');for(const k of ['forklifts','tugs','walkers','maintenanceParts','kitsInbound'])if(!Number.isInteger(c[k]))throw Error(k+' must be a whole number.');return c}
 function materialPhysics(specs,materials){
  const out={};for(const [id,m]of Object.entries(materials))out[id]={mass:m.unit==='kg'?1:({processor:.6,sensorModule:.45,safingModule:.8,regValve:1.5,regSense:.2}[id]||1),volume:m.volume,envelope:m.unit==='kg'?[.1,.1,.1]:m.volume>=1?[2.4,1.6,m.volume/3.84]:Array(3).fill(Math.cbrt(m.volume))};
  for(const type of FactoryEngine.topological(specs)){const s=specs[type],mass=Object.entries(s.inputs).reduce((n,[k,q])=>n+out[k].mass*q,0),count=sum(s.outputs);if(count)for(const k of Object.keys(s.outputs))out[k].mass=mass/count}
  return out;
 }
 function payload(item,kind,physics){const p=physics[item],v=VEHICLES[kind];if(!p||p.envelope.slice().sort((a,b)=>a-b).some((n,i)=>n>v.deck.slice().sort((a,b)=>a-b)[i]+EPS))return 0;const q=Math.min(v.volume/p.volume,v.payload/Math.max(p.mass,EPS));return Math.max(0,q)}
 function initial(buildings,specs,materials,config={},workers=[],upgrades={}){
  const c=settings(config),physics=materialPhysics(specs,materials),state={version:1,day:0,stockItems:{},stocks:{},inputs:{},outputs:{},work:{},conditions:{},employees:{},wip:{},fleetPositions:{},maintenanceParts:c.maintenanceParts,cumulative:{shipped:0,cost:0},history:[]};
  const wanted={};for(const b of Object.values(buildings)){for(const s of b.storage){state.stocks[s.id]=s.stock||0;state.stockItems[s.id]=s.item}for(const m of b.machines){state.conditions[m.id]=m.condition;state.inputs[m.id]={};state.outputs[m.id]={};for(const w of m.crew)state.employees[w.id]={level:w.level};if(!specs[m.type].support)for(const [item,n]of Object.entries(specs[m.type].inputs))if(!['tested','shipped'].includes(item)&&materials[item].unit!=='kg'&&Object.values(specs).some(s=>Object.hasOwn(s.outputs,item)))wanted[item]=(wanted[item]||0)+n*Math.max(1,Math.ceil(FactoryEngine.effectiveRate(m,specs,upgrades)*c.bufferMinutes/540))}}
  for(const w of workers)state.employees[w.id]={level:w.level};
  // An explicit scenario allocation of the register's unlocated WIP, never added
  // to raw stock or silently debited from it a second time.
  const engineMass=physics.shipped?.mass||physics.tested?.mass||1,total=Object.entries(wanted).reduce((n,[k,q])=>n+physics[k].mass*q,0),fraction=total?c.openingWip*engineMass/total:0;
  for(const [k,q]of Object.entries(wanted))state.wip[k]=Math.floor(q*fraction);
  let stagedMass=0;for(const b of Object.values(buildings))for(const m of b.machines){const s=specs[m.type],batches=Math.max(1,Math.ceil(FactoryEngine.effectiveRate(m,specs,upgrades)*c.bufferMinutes/540));for(const [item,q]of Object.entries(s.inputs)){if(!Object.hasOwn(state.wip,item))continue;const amount=Math.min(state.wip[item],q*batches);state.inputs[m.id][item]=amount;state.wip[item]-=amount;stagedMass+=amount*physics[item].mass}}
  let phased=0;if(c.phaseOpeningWork&&c.openingWip>0){let index=0;for(const b of Object.values(buildings))for(const m of b.machines){index++;const s=specs[m.type],rate=FactoryEngine.effectiveRate(m,specs,upgrades);if(s.support||rate<EPS||!Object.keys(s.inputs).length||Object.entries(s.inputs).some(([k,q])=>(state.inputs[m.id][k]||0)+EPS<q))continue;const fraction=.08+.84*((index*37)%101)/100;state.work[m.id]={inputs:copy(s.inputs),remaining:32400/rate*fraction};for(const [k,q]of Object.entries(s.inputs))state.inputs[m.id][k]-=q;phased++}}
  state.openingWipAssumption={phasedOperations:phased,cycleProgress:'Existing internal-only work distributed across estimated remaining cycle times; not a measured WIP census',stagedMassKg:stagedMass,engineEquivalents:c.openingWip,massKg:c.openingWip*engineMass,allocation:'Unverified stage allocation: intermediate WIP staged at consuming stations, with surplus in receiving WIP store. Raw feeds and bought parts remain warehouse stock.'};return state;
 }
 class Heap{constructor(){this.a=[]}push(v){let i=this.a.length;this.a.push(v);while(i){const p=(i-1)>>1;if(this.a[p].time<=v.time)break;this.a[i]=this.a[p];i=p}this.a[i]=v}pop(){const top=this.a[0],last=this.a.pop();if(this.a.length){let i=0;for(;;){let c=i*2+1;if(c>=this.a.length)break;if(c+1<this.a.length&&this.a[c+1].time<this.a[c].time)c++;if(this.a[c].time>=last.time)break;this.a[i]=this.a[c];i=c}this.a[i]=last}return top}get size(){return this.a.length}get first(){return this.a[0]}}
 class Lru extends Map{constructor(limit){super();this.limit=limit}get(k){const value=super.get(k);if(super.has(k)){super.delete(k);super.set(k,value)}return value}set(k,v){super.delete(k);super.set(k,v);if(this.size>this.limit)super.delete(this.keys().next().value);return this}}
 function geometry(buildings,specs){
  const floors={},names=Object.keys(buildings),anchors={};const known={Receiving:[20,80],'Factory A':[100,20],'Factory B':[180,20],'Precision Machining':[100,80],Subassemblies:[180,80],'Final Assembly & Test':[260,80]};names.forEach((n,i)=>anchors[n]=known[n]||[20+i*60,20]);
  for(const [name,b]of Object.entries(buildings)){const blocked=new Set(),paths=new Map();for(const o of [...b.machines,...b.storage])for(let y=o.y;y<o.y+o.h;y++)for(let x=o.x;x<o.x+o.w;x++)blocked.add(x+','+y);for(const p of b.paths)paths.set(p.x+','+p.y,p);const lanes=FactoryEngine.cartCells(b);const walkable=new Uint8Array(b.cols*b.rows),terrain=new Uint8Array(b.cols*b.rows);for(let y=0;y<b.rows;y++)for(let x=0;x<b.cols;x++){const k=x+','+y,p=paths.get(k),index=y*b.cols+x;walkable[index]=!blocked.has(k)&&p?.kind!=='belt'?1:0;terrain[index]=p?.kind==='cart'?1:0}floors[name]={b,blocked,paths,walkable,terrain,lanes}}
  const cache=new Lru(4000);
  const point=(scene,x,y)=>[scene,x,y],id=p=>JSON.stringify(p),free=(name,x,y,kind)=>{const f=floors[name],p=f.paths.get(x+','+y);return x>=0&&y>=0&&x<f.b.cols&&y<f.b.rows&&!f.blocked.has(x+','+y)&&p?.kind!=='belt'&&(kind==='walker'||!f.lanes.narrow.has(x+','+y))};
  function ends(o,output){if(o.points)return o.points;const s=specs[o.type];if(s&&(s.port==='fixed'||(output?o.outputSide:o.inputSide)))return FactoryEngine.accessPoints(o,specs,output);const a=[];for(let x=o.x;x<o.x+o.w;x++)a.push([x,o.y-1],[x,o.y+o.h]);for(let y=o.y;y<o.y+o.h;y++)a.push([o.x-1,y],[o.x+o.w,y]);return a}
  function local(name,source,target,kind,output=true){
   const ck=name+'|'+source.id+'|'+target.id+'|'+(kind==='walker'?'walker':'drive')+'|'+output;
   if(cache.has(ck))return cache.get(ck);
   const f=floors[name],cols=f.b.cols,rows=f.b.rows,size=cols*rows,goals=new Set(),coordinates=[];
   const open=(x,y)=>x>=0&&y>=0&&x<cols&&y<rows&&f.walkable[y*cols+x]&&(kind==='walker'||!f.lanes.narrow.has(x+','+y));
   for(const [x,y]of ends(target,false))if(open(x,y)){const id=y*cols+x;if(!goals.has(id)){goals.add(id);coordinates.push([x,y])}}
   if(!coordinates.length){cache.set(ck,null);return null}
   const minX=Math.min(...coordinates.map(p=>p[0])),maxX=Math.max(...coordinates.map(p=>p[0])),minY=Math.min(...coordinates.map(p=>p[1])),maxY=Math.max(...coordinates.map(p=>p[1])),heuristic=(x,y)=>Math.max(0,minX-x,x-maxX)+Math.max(0,minY-y,y-maxY);
   const queue=new Heap(),prev=new Int32Array(size),dist=new Float64Array(size);prev.fill(-2);dist.fill(Infinity);
   for(const [x,y]of ends(source,output))if(open(x,y)){const node=y*cols+x;prev[node]=-1;dist[node]=0;queue.push({time:heuristic(x,y),g:0,node})}
   let found=-1;
   while(queue.size){const {node,g:time}=queue.pop();if(time!==dist[node])continue;if(goals.has(node)){found=node;break}const x=node%cols,y=Math.floor(node/cols);
    for(let direction=0;direction<4;direction++){const nx=x+(direction===0?1:direction===2?-1:0),ny=y+(direction===1?1:direction===3?-1:0);if(!open(nx,ny))continue;const next=ny*cols+nx,cost=time+(f.terrain[next]?1:kind==='walker'?1.5:4);
     if(cost<dist[next]){dist[next]=cost;prev[next]=node;queue.push({time:cost+heuristic(nx,ny),g:cost,node:next})}
    }
   }
   const path=[];while(found>=0){path.push(point(name,found%cols,Math.floor(found/cols)));found=prev[found]}
   const result=path.length?path.reverse():null;cache.set(ck,result);return result;
  }

  function dock(name,kind){return {id:name+'-'+kind,points:buildings[name].docks?.[kind]||[]}}
  function road(a,b){const out=[],p=anchors[a],q=anchors[b];if(!p||!q)return null;let [x,y]=p;out.push(point('@campus',x,y));x++;out.push(point('@campus',x,y));const lane=q[0]>=p[0]?49:51;while(y!==lane){y+=Math.sign(lane-y);out.push(point('@campus',x,y))}while(x!==q[0]-1){x+=Math.sign(q[0]-1-x);out.push(point('@campus',x,y))}while(y!==q[1]){y+=Math.sign(q[1]-y);out.push(point('@campus',x,y))}x++;out.push(point('@campus',x,y));return out}
  function route(source,target,kind){if(source.building===target.building)return local(source.building,source,target,kind);const a=local(source.building,source,dock(source.building,'output'),kind),b=local(target.building,dock(target.building,'input'),target,kind),r=road(source.building,target.building);return a&&b&&r?[...a,...r,...b]:null}
  function approach(node,kind){return local(node.building,dock(node.building,'input'),node,kind)}
  function exit(node,kind){return local(node.building,node,dock(node.building,'output'),kind)}
  function belt(source,target,item){if(source.building!==target.building)return null;const name=source.building,ck='belt|'+source.id+'|'+target.id+'|'+item;if(cache.has(ck))return cache.get(ck);const f=floors[name],allowed=(x,y)=>{const p=f.paths.get(x+','+y);return p?.kind==='belt'&&p.cargo===item},goals=new Set(ends(target,false).filter(p=>allowed(...p)).map(p=>p.join(','))),q=[],prev=new Map();for(const p of ends(source,true))if(allowed(...p)){q.push(p);prev.set(p.join(','),null)}let found=null;for(let i=0;i<q.length;i++){const [x,y]=q[i],k=x+','+y;if(goals.has(k)){found=k;break}const dir=f.paths.get(k).dir,[dx,dy]=[[1,0],[0,1],[-1,0],[0,-1]][dir],nx=x+dx,ny=y+dy,nk=nx+','+ny;if(allowed(nx,ny)&&!prev.has(nk)){prev.set(nk,k);q.push([nx,ny])}}const a=[];while(found!==null){a.push(point(name,...found.split(',').map(Number)));found=prev.get(found)}const result=a.length?a.reverse():null;cache.set(ck,result);return result}
  return {floors,names,anchors,route,approach,exit,road,id,local,dock,free,belt};
 }
 // Traffic reservations cover the whole carrier and its following clearance square.
 // A trip yields in its off-floor holding area until its complete route is safe.
 // No head-on swaps or occupied-cell crossings are permitted, including service stops.
 class Traffic{
  constructor(geo=null,doorSeconds=2){this.geo=geo;this.doorSeconds=doorSeconds;this.cells=new Map();this.edges=new Map();this.plans=new Map();this.failed=new WeakMap();this.failedRoutes=new Lru(8192);this.prunedBefore=0;this.waitSeconds=0;this.conflicts=0}
  conflict(map,key,start,end){const a=map.get(key);if(!a)return null;let lo=0,hi=a.length;while(lo<hi){const m=(lo+hi)>>1;if(a[m][1]<=start)lo=m+1;else hi=m}const r=a[lo];return r&&r[0]<end?r:null}
  insert(map,key,row){let a=map.get(key);if(!a){map.set(key,[row]);return}let lo=0,hi=a.length;while(lo<hi){const m=(lo+hi)>>1;if(a[m][0]<row[0])lo=m+1;else hi=m}a.splice(lo,0,row)}
  plan(path,kind,pickupIndex,dropIndex){
   const ck=kind+'|'+pickupIndex+'|'+dropIndex;let cached=this.plans.get(path);if(cached?.has(ck))return cached.get(ck);if(!cached){cached=new Map();this.plans.set(path,cached);if(this.plans.size>256)this.plans.delete(this.plans.keys().next().value)}
   const v=VEHICLES[kind],steps=[],merged=new Map(),edges=[];let duration=0;
   for(let i=0;i<path.length;i++){
    const p=path[i],previous=path[i-1],transition=previous&&previous[0]!==p[0],terrain=this.geo?.floors[p[0]]?.paths.get(p[1]+','+p[2])?.kind,speed=v.speed*(kind==='walker'||p[0]==='@campus'||terrain==='cart'?1:.35),dt=Math.ceil(transition?this.doorSeconds:2/speed)+(i===pickupIndex||i===dropIndex?v.loadSeconds:0);steps.push(duration);
    const occupied=new Set();for(let j=Math.max(0,i-v.length+1);j<=i;j++)if(path[j][0]===p[0])occupied.add(path[j][0]+':'+path[j][1]+','+path[j][2]);
    for(const k of occupied){const rows=merged.get(k)||[],last=rows.at(-1);if(last&&last[1]>=duration)last[1]=Math.max(last[1],duration+dt);else rows.push([duration,duration+dt]);merged.set(k,rows)}
    if(previous&&previous[0]===p[0]){const a=previous[0]+':'+previous[1]+','+previous[2],b=p[0]+':'+p[1]+','+p[2];edges.push([a<b?a+'>'+b:b+'>'+a,duration,duration+dt])}duration+=dt;
   }
   const result={steps,merged,edges,duration};cached.set(ck,result);return result;
  }
  blockedRoute(key,earliest,latest,maxStart){const entry=this.failedRoutes.get(key);if(!entry||earliest<this.prunedBefore)return false;const low=Math.ceil(earliest),high=Math.floor(Math.min(latest-entry.duration,maxStart));if(low<=high&&entry.windows.some(([a,b])=>a<=low&&b>=high)){this.conflicts++;return true}return false}
  reserve(path,kind,earliest,pickupIndex,dropIndex,latest=Infinity,maxStart=Infinity,routeKey=null){
   if(Math.ceil(earliest)>maxStart)return null;
   if(routeKey&&this.blockedRoute(routeKey,earliest,latest,maxStart))return null;
   const key=kind+'|'+pickupIndex+'|'+dropIndex,failures=routeKey?null:this.failed.get(path)?.get(key);
   if(failures){const low=Math.ceil(earliest),high=Math.floor(Math.min(latest-failures.duration,maxStart));if(low<=high&&failures.windows.some(([a,b])=>a<=low&&b>=high)){this.conflicts++;return null}}
   const {steps,merged,edges,duration}=this.plan(path,kind,pickupIndex,dropIndex),v=VEHICLES[kind];if(earliest+duration>latest)return null;
   let start=Math.ceil(earliest);const firstStart=start,lastStart=Math.min(latest-duration,maxStart);if(start>lastStart)return null;
   // Departures use integer seconds. Mark forbidden starts in a small exact
   // bitset instead of sorting all future bookings. Every cell, tail and edge
   // reservation is still checked, with the same half-open interval rules.
   const CHUNK=1024,blocked=new Uint32Array(CHUNK/32);let found=false,delayed=false;
   while(start<=lastStart){blocked.fill(0);const end=Math.floor(Math.min(lastStart,start+CHUNK-1)),words=Math.ceil((end-start+1)/32),bits=(end-start+1)%32;let full=false,jump=end+1,fullWords=0;if(bits)blocked[words-1]=0xffffffff<<bits;const mark=(word,mask)=>{const old=blocked[word];blocked[word]|=mask;if(old!==0xffffffff&&blocked[word]===0xffffffff)fullWords++;if(fullWords===words)full=true};
    const exclude=(map,key,a,b)=>{if(full)return;const rows=map.get(key);if(!rows)return;let lo=0,hi=rows.length;while(lo<hi){const mid=(lo+hi)>>1;if(rows[mid][1]<=start+a)lo=mid+1;else hi=mid}
     for(let i=lo;i<rows.length;i++){const [s,e]=rows[i];if(s>=end+b)break;const low=Math.max(start,s-b+1),high=Math.min(end,e-a-1);if(low>high)continue;
      if(low===start&&high===end){full=true;jump=Math.max(jump,e-a);return}
      const left=low-start,right=high-start,first=left>>>5,last=right>>>5,head=0xffffffff<<(left&31),tail=0xffffffff>>>(31-(right&31));
      if(first===last)mark(first,head&tail);else{mark(first,head);for(let word=first+1;word<last;word++)mark(word,0xffffffff);mark(last,tail)}if(full)return;
     }
    };
    for(const [key,rows]of merged){if(full)break;for(const [a,b]of rows)exclude(this.cells,key,a,b)}
    if(!full)for(const [key,a,b]of edges){exclude(this.edges,key,a,b);if(full)break}
    if(!full){for(let word=0;word<blocked.length;word++){const available=~blocked[word]>>>0;if(!available)continue;const candidate=start+word*32+31-Math.clz32((available&-available)>>>0);if(candidate<=end){start=candidate;found=true}break}}
    if(found)break;delayed=true;start=jump;
   }
   // Diagnostic count is delayed/blocked searches, not implementation-specific
   // intermediate interval merges. Actual waiting time remains exact.
   if(delayed||start>firstStart)this.conflicts++;if(!found){
    // Extra bookings cannot make a failed window feasible. Reuse that exact
    // fact for contained searches; pruning resets this monotone cache.
    let map=this.failed.get(path);if(!map){map=new Map();this.failed.set(path,map)}const entry=(routeKey?this.failedRoutes.get(routeKey):map.get(key))||{duration,windows:[]},low=firstStart,high=Math.floor(lastStart);entry.windows.push([low,high]);entry.windows.sort((a,b)=>a[0]-b[0]);const merged=[];for(const row of entry.windows){const last=merged.at(-1);if(last&&row[0]<=last[1]+1)last[1]=Math.max(last[1],row[1]);else merged.push(row)}entry.windows=merged;map.set(key,entry);if(routeKey)this.failedRoutes.set(routeKey,entry);return null;
   }

   for(const [k,rows]of merged)for(const [a,b]of rows)this.insert(this.cells,k,[start+a,start+b]);for(const [k,a,b]of edges)this.insert(this.edges,k,[start+a,start+b]);this.waitSeconds+=start-earliest;
   return {start,end:start+duration,pickup:start+steps[pickupIndex]+v.loadSeconds,drop:start+steps[dropIndex]+v.loadSeconds,times:steps};
  }
  prune(time){this.failed=new WeakMap();this.prunedBefore=Math.max(this.prunedBefore,time);for(const map of [this.cells,this.edges])for(const [k,a]of map){let n=0;while(n<a.length&&a[n][1]<time)n++;if(n===a.length)map.delete(k);else if(n)a.splice(0,n)}}
 }

 function validateState(state,buildings,materials,workers){
  if(!state||state.version!==1||!Number.isInteger(state.day)||state.day<0||state.day>1000000)throw Error('Invalid operating ledger.');
  const machines=new Set(Object.values(buildings).flatMap(b=>b.machines.map(m=>m.id))),stocks=new Map(Object.values(buildings).flatMap(b=>b.storage.map(s=>[s.id,s]))),people=new Set(workers.map(w=>w.id));
  const quantities=(items,label)=>{if(!items||typeof items!=='object'||Array.isArray(items))throw Error('Missing '+label);for(const [k,n]of Object.entries(items))if(!Object.hasOwn(materials,k)||!Number.isFinite(n)||n< -EPS||n>1e12)throw Error('Invalid '+label+' balance.')};
  for(const [key,balances]of Object.entries({inputs:state.inputs,outputs:state.outputs})){if(!balances||typeof balances!=='object')throw Error('Missing '+key);for(const [id,items]of Object.entries(balances)){if(!machines.has(id))throw Error('Ledger references removed tile '+id);quantities(items,key)}}
  for(const [id,n]of Object.entries(state.stocks||{}))if(!stocks.has(id)||!Number.isFinite(n)||n< -EPS||n>FactoryEngine.storageCap(stocks.get(id),materials)+EPS)throw Error('Invalid warehouse stock');
  quantities(state.wip,'WIP');if(state.looseInventoryCredit)quantities(state.looseInventoryCredit,'carried warehouse stock');for(const [id,n]of Object.entries(state.conditions||{}))if(!machines.has(id)||!Number.isFinite(n)||n<0||n>1)throw Error('Invalid machine condition');
  for(const [id,w]of Object.entries(state.work||{})){if(!machines.has(id)||!Number.isFinite(w.remaining)||w.remaining<0||w.remaining>1e9)throw Error('Invalid unfinished operation');quantities(w.inputs,'unfinished work')}
  for(const [id,e]of Object.entries(state.employees||{}))if(!people.has(id)||!Number.isInteger(e.level)||e.level<0||e.level>5||['xpHours','totalHours'].some(k=>e[k]!==undefined&&(!Number.isFinite(e[k])||e[k]<0)))throw Error('Invalid employee ledger');
  for(const [id,v]of Object.entries(state.fleetPositions||{}))if(!/^(tug|forklift|walker)-[0-9]+$/.test(id)||!Object.hasOwn(VEHICLES,v.kind)||!Object.hasOwn(buildings,v.parking)||!people.has(v.driver))throw Error('Invalid fleet parking state.');
  if(!Number.isInteger(state.maintenanceParts)||state.maintenanceParts<0||!state.cumulative||!Number.isFinite(state.cumulative.shipped)||state.cumulative.shipped<0||!Number.isFinite(state.cumulative.cost)||state.cumulative.cost<0||!Array.isArray(state.history)||state.history.length>90||state.history.some(h=>!['day','certified','shipped','prepHours','cost'].every(k=>Number.isFinite(h[k])&&h[k]>=0)))throw Error('Invalid operating history, cost or service stock.');return state;
 }

 function simulate(buildings,specs,materials,inputState,workers=[],rawConfig={},supply={},upgrades={},onProgress=()=>{}){
  const config=settings(rawConfig),state=copy(inputState),initialState=copy(inputState),geo=geometry(buildings,specs),physics=materialPhysics(specs,materials),traffic=new Traffic(geo,config.doorSeconds),queue=new Heap(),nodes={},all=[],stores=[],sources={},events=[],trips=[],paths=[],pathIndex=new Map(),tripPaths=new Lru(2000),failedPaths=new Set(),candidateOrder=new Map(),machines={},stage={},details={},reserved={},pending={},pickupBookings={},retryAt={},totals={opening:{},incoming:{},consumed:{},produced:{},shipped:{}},ledger=[],diagnostics=new Set(),workHours={},service=[],promotions=[];
  const loadLimits=Object.fromEntries(Object.keys(materials).map(item=>[item,Object.fromEntries(Object.keys(VEHICLES).map(kind=>[kind,payload(item,kind,physics)]))]));
  const beltReady=new Map(),scenes=new Map([...geo.names,'@campus'].map((n,i)=>[n,i+1]));
  let serial=0,now=0,prepEnd=0,shiftEnd=Infinity,phase='prep',shipped=0;
  const add=(o,k,q)=>o[k]=(o[k]||0)+q;
  function event(time,type,data){queue.push({time,type,data,serial:serial++})}
  function record(type,time,data){events.push({type,time,...data})}
  function balance(node,item){return node.kind==='storage'?state.stocks[node.id]||0:node.kind==='wip'?state.wip[item]||0:node.kind==='sink'?0:node.kind==='input'?state.inputs[node.machine][item]||0:state.outputs[node.id][item]||0}
  function change(node,item,n){if(node.kind==='storage')add(state.stocks,node.id,n);else if(node.kind==='wip')add(state.wip,item,n);else if(node.kind==='input')add(state.inputs[node.machine],item,n);else if(node.kind!=='sink')add(state.outputs[node.id],item,n)}
  function remaining(node,item){return Math.max(0,balance(node,item)-(reserved[node.id+'|'+item]||0))}
  const receiving=geo.names.find(n=>/receiving/i.test(n))||geo.names[0];
  for(const [building,b]of Object.entries(buildings)){
   for(const s of b.storage){const node={...s,kind:'storage',building};nodes[s.id]=node;stores.push(node);(sources[s.item]??=[]).push(node)}
   for(const m of b.machines){const node={...copy(m),kind:'output',building};nodes[m.id]=node;all.push(node);state.inputs[m.id]??={};state.outputs[m.id]??={};node.condition=state.conditions[m.id]??m.condition;node.crew=node.crew.map(w=>({...w,...state.employees[w.id]}));machines[m.id]=0;details[m.id]={capacity:0,blocked:0,shortages:{},inputSupply:{},inputNeed:{},busySeconds:0};stage[m.type]??={rated:0,possible:0,actual:0,machines:0};stage[m.type].machines++;for(const item of Object.keys(specs[m.type].outputs))(sources[item]??=[]).push(node)}
  }
  const pausedWork=new Set();const wipPorts=buildings[receiving].docks.input;for(const [i,item]of Object.keys(state.wip).entries()){const wipNode={id:'opening-wip-'+item,kind:'wip',building:receiving,points:wipPorts.length?[wipPorts[i%wipPorts.length]]:[]};(sources[item]??=[]).push(wipNode)}
  const sink={id:'dispatch',kind:'sink',building:geo.names.find(n=>/final/i.test(n))||geo.names.at(-1),points:[]};sink.points=buildings[sink.building].docks.output;
  function inventoryTotals(){const t={};for(const n of stores)add(t,n.item,balance(n,n.item));for(const [k,q]of Object.entries(state.wip))add(t,k,q);for(const n of all)for(const map of [state.inputs[n.id],state.outputs[n.id],state.work[n.id]?.inputs||{}])for(const [k,q]of Object.entries(map))add(t,k,q);return t}
  totals.opening=inventoryTotals();
  state.maintenanceParts+=config.kitsInbound;
  const availableStaff=workers.filter(w=>w.role==='handling').map(w=>({...w,...state.employees[w.id]})).sort((a,b)=>b.level-a.level||a.id.localeCompare(b.id));
  const vehicles=[];for(const [kind,count]of [['tug',config.tugs],['forklift',config.forklifts],['walker',config.walkers]])for(let i=0;i<count;i++){const id=kind+'-'+(i+1),previous=state.fleetPositions?.[id],driverIndex=previous?availableStaff.findIndex(w=>w.id===previous.driver):-1,driver=driverIndex>=0?availableStaff.splice(driverIndex,1)[0]:availableStaff.shift();if(!driver)break;const parking=previous&&geo.names.includes(previous.parking)?previous.parking:receiving;vehicles.push({id,kind,driver:driver.id,level:driver.level,available:0,parking,startParking:parking})}
  if(vehicles.length<config.tugs+config.forklifts+config.walkers)diagnostics.add('Carrier availability is limited by the existing unassigned handling staff; no duplicated drivers.');
  const technicians=[...workers.filter(w=>w.role==='shiftSupport'),...all.filter(m=>specs[m.type].support).flatMap(m=>m.crew)].filter(w=>(state.employees[w.id]?.level??w.level)>=2).map(w=>({id:w.id,level:state.employees[w.id]?.level??w.level,available:0}));
  for(const m of all){if(m.condition+config.serviceTrigger+EPS>=config.maintenanceTarget)continue;const tech=technicians.sort((a,b)=>a.available-b.available||a.id.localeCompare(b.id))[0];if(!tech||state.maintenanceParts<1){diagnostics.add('Maintenance stopped: insufficient qualified technicians or service kits.');break}const walk=tech.location?geo.route(nodes[tech.location],m,'walker'):geo.approach(m,'walker');if(!walk){diagnostics.add('No maintenance access to '+m.id);continue}const walkSeconds=walk.length*2,walkStart=tech.available;const delta=config.maintenanceTarget-m.condition,duration=60*(config.serviceMinutes+delta*100*config.serviceMinutesPerPoint)/(1+.08*tech.level),start=tech.available+walkSeconds,end=start+duration;tech.available=end;tech.location=m.id;state.maintenanceParts--;service.push({machine:m.id,worker:tech.id,start,end,from:m.condition,to:config.maintenanceTarget,building:m.building,x:m.x,y:m.y,walkStart,walkEnd:start,path:internPath(walk)});add(workHours,tech.id,(duration+walkSeconds)/3600);event(end,'service',{id:m.id,condition:config.maintenanceTarget});prepEnd=Math.max(prepEnd,end);record('maintenance-start',start,{machine:m.id,worker:tech.id});record('maintenance-end',end,{machine:m.id,worker:tech.id,condition:config.maintenanceTarget})}
  function internPath(path){let a=2166136261,b=5381;for(const p of path){const v=(scenes.get(p[0])||0)*1000000+p[1]*1000+p[2];a=Math.imul(a^v,16777619)>>>0;b=(Math.imul(b,33)^v)>>>0}let k=path.length+':'+a+':'+b;if(pathIndex.has(k)){const id=pathIndex.get(k),old=paths[id];if(old.every((p,i)=>p[0]===path[i][0]&&p[1]===path[i][1]&&p[2]===path[i][2]))return id;k+=':'+paths.length}const id=paths.length;paths.push(path);pathIndex.set(k,id);return id}
  function vehicleEta(v,building,time){const a=geo.anchors[v.parking],b=geo.anchors[building],distance=v.parking===building?0:Math.abs(a[0]-b[0])+Math.abs(a[1]-50)+Math.abs(b[1]-50);return Math.max(time,v.available)+distance*2/VEHICLES[v.kind].speed}
  function schedule(source,target,item,wanted,time){
   let amount=Math.min(wanted,remaining(source,item));if(amount<EPS)return 0;
   const belt=geo.belt(source,target,item);
   if(belt){const start=Math.max(time,...belt.map(p=>beltReady.get(geo.id(p))||0)),volumeSeconds=amount*materials[item].volume/(config.beltSpeed*config.beltVolumePerMetre),drop=start+volumeSeconds+belt.length*2/config.beltSpeed;if(phase==='prep'||drop<=shiftEnd){for(const p of belt)beltReady.set(geo.id(p),start+volumeSeconds);const trip={id:'trip-'+trips.length,vehicle:'belt-'+source.id+'-'+target.id,kind:'belt',driver:null,item,amount,from:source.id,to:target.id,sourceBuilding:source.building,targetBuilding:target.building,path:internPath(belt),pickupIndex:0,dropIndex:belt.length-1,start,end:drop+.01,pickup:start,drop,times:belt.map((p,i)=>i*2/config.beltSpeed+volumeSeconds*i/Math.max(1,belt.length-1)),wait:start-time};trips.push(trip);add(reserved,source.id+'|'+item,amount);(pickupBookings[source.id+'|'+item]??=[]).push({time:start,amount});add(pending,target.id+'|'+item,amount);event(start,'pickup',{trip:trips.length-1,source});event(drop,'drop',{trip:trips.length-1,target});if(phase==='prep')prepEnd=Math.max(prepEnd,drop+.01);return amount}}
   if(phase==='shift'&&vehicles.every(v=>v.available>=shiftEnd))return 0;
   const best={};for(const v of vehicles){if((phase==='shift'&&v.available>=shiftEnd)||loadLimits[item][v.kind]<EPS)continue;const previous=best[v.kind],eta=vehicleEta(v,source.building,time);if(!previous||eta<vehicleEta(previous,source.building,time))best[v.kind]=v}const candidates=Object.values(best).sort((a,b)=>vehicleEta(a,source.building,time)-vehicleEta(b,source.building,time)||loadLimits[item][b.kind]-loadLimits[item][a.kind]);
   for(const vehicle of candidates){
    const cap=loadLimits[item][vehicle.kind];amount=Math.min(amount,cap);if(materials[item].unit==='each')amount=Math.floor(amount+EPS);if(amount<EPS)continue;
    if(phase==='shift'&&Math.ceil(Math.max(time,vehicle.available))>time+config.dispatchLookaheadMinutes*60)continue;
    const cacheKey=vehicle.parking+'|'+source.id+'|'+target.id+'|'+vehicle.kind;if(phase==='shift'&&traffic.blockedRoute(cacheKey,Math.max(time,vehicle.available),shiftEnd,time+config.dispatchLookaheadMinutes*60))continue;if(phase==='shift'&&failedPaths.has(cacheKey))continue;let bundle=tripPaths.get(cacheKey);if(bundle===null)continue;if(!bundle){const b=geo.route(source,target,vehicle.kind);if(!b){tripPaths.set(cacheKey,null);continue}const fromPoint={id:source.id+':pickup:'+b[0].slice(1).join(','),points:[b[0].slice(1)]},toPoint={id:target.id+':drop:'+b.at(-1).slice(1).join(','),points:[b.at(-1).slice(1)]};const a=geo.local(source.building,geo.dock(source.building,'input'),fromPoint,vehicle.kind),c=geo.local(target.building,toPoint,geo.dock(target.building,'output'),vehicle.kind);if(!a||!c){tripPaths.set(cacheKey,null);continue;}
    const reposition=vehicle.parking===source.building?[]:geo.road(vehicle.parking,source.building),path=[...reposition,...a,...b.slice(1),...c.slice(1)],pickupIndex=reposition.length+a.length-1,dropIndex=reposition.length+a.length+b.length-2;bundle={path,pickupIndex,dropIndex};tripPaths.set(cacheKey,bundle)}const {path,pickupIndex,dropIndex}=bundle;
    const earliest=Math.max(time,vehicle.available);if(phase==='shift'&&earliest+Math.ceil(path.length*2/VEHICLES[vehicle.kind].speed)+2*VEHICLES[vehicle.kind].loadSeconds>shiftEnd){failedPaths.add(cacheKey);continue}const planned=traffic.reserve(path,vehicle.kind,earliest,pickupIndex,dropIndex,phase==='shift'?shiftEnd:Infinity,phase==='shift'?time+config.dispatchLookaheadMinutes*60:Infinity,cacheKey);if(!planned){if(phase==='shift'&&time+config.dispatchLookaheadMinutes*60>=shiftEnd)failedPaths.add(cacheKey);continue;}
    // Never create a post-shift shipment; tasks accepted during production must
    // deliver and return before closing. Pending trips are part of the ledger.
    if(phase==='shift'&&planned.end>shiftEnd){continue}
    const pathId=internPath(path);const trip={id:'trip-'+trips.length,vehicle:vehicle.id,kind:vehicle.kind,holdingBuilding:vehicle.parking,driver:vehicle.driver,item,amount,from:source.id,to:target.id,sourceBuilding:source.building,targetBuilding:target.building,path:pathId,pickupIndex,dropIndex,...planned,wait:planned.start-earliest};trips.push(trip);vehicle.available=planned.end;vehicle.parking=target.building;add(reserved,source.id+'|'+item,amount);(pickupBookings[source.id+'|'+item]??=[]).push({time:planned.pickup,amount});add(pending,target.id+'|'+item,amount);event(planned.pickup,'pickup',{trip:trips.length-1,source});event(planned.drop,'drop',{trip:trips.length-1,target});add(workHours,vehicle.driver,(planned.end-earliest)/3600);if(phase==='prep')prepEnd=Math.max(prepEnd,planned.end);return amount;
   }
   return 0;
  }
  function candidatesFor(m,item){const key=m.id+'|'+item;let ordered=candidateOrder.get(key);if(!ordered){ordered=(sources[item]||[]).filter(n=>n.id!==m.id).sort((a,b)=>(a.building===m.building?0:10000)-(b.building===m.building?0:10000)+Math.abs((a.x||0)-m.x)+Math.abs((a.y||0)-m.y)-Math.abs((b.x||0)-m.x)-Math.abs((b.y||0)-m.y)||a.id.localeCompare(b.id));candidateOrder.set(key,ordered)}return ordered.filter(n=>remaining(n,item)>EPS)}
  function request(m,time){const s=specs[m.type];if(s.support)return;if(phase==='shift'&&state.work[m.id]&&time<state.work[m.id].finish-config.bufferMinutes*60)return;const batches=Math.max(1,Math.ceil(FactoryEngine.effectiveRate(m,specs,upgrades)*config.bufferMinutes/540));for(const [item,q]of Object.entries(s.inputs)){
    const requestKey=m.id+'|'+item;if((retryAt[requestKey]||0)>time)continue;const target={...m,id:'in:'+m.id,kind:'input',machine:m.id},need=q*batches-(state.inputs[m.id][item]||0)-(pending[target.id+'|'+item]||0);if(need<EPS)continue;let missing=need;
    for(const source of candidatesFor(m,item).slice(0,4)){let attempts=0;while(missing>EPS&&remaining(source,item)>EPS&&attempts++<30){const delivered=schedule(source,target,item,missing,time);if(!delivered)break;missing-=delivered}if(missing<EPS)break}if(missing>EPS&&phase==='shift')retryAt[requestKey]=time+300;
   }}
  function applyEvents(until){while(queue.size&&queue.first.time<=until){const e=queue.pop();now=e.time;const d=e.data;if(e.type==='service'){nodes[d.id].condition=d.condition;state.conditions[d.id]=d.condition}else if(e.type==='pickup'){const t=trips[d.trip];change(d.source,t.item,-t.amount);add(reserved,d.source.id+'|'+t.item,-t.amount);record('pickup',e.time,{trip:d.trip})}else if(e.type==='drop'){const t=trips[d.trip];if(d.target.kind==='sink'){shipped+=t.amount;add(totals.shipped,t.item,t.amount)}else change(d.target,t.item,t.amount);add(pending,d.target.id+'|'+t.item,-t.amount);if(d.target.kind==='input')add(details[d.target.machine].inputSupply,t.item,t.amount);record('drop',e.time,{trip:d.trip})}else if(e.type==='complete'){const m=nodes[d.id],s=specs[m.type];for(const [item,q]of Object.entries(s.outputs)){change(m,item,q);add(totals.produced,item,q)}if(state.work[m.id]?.resumed)for(const [k,q]of Object.entries(state.work[m.id].inputs))add(totals.consumed,k,q);delete state.work[m.id];machines[m.id]++;stage[m.type].actual++;record('work-end',e.time,{machine:m.id})}}now=until}
  // Scenario arrivals are booked explicitly and separately from confirmed stock.
  // They are placed in receiving bins only when there is actual storage capacity.
  for(const [item,q]of Object.entries(supply)){if(!materials[item]||!Number.isFinite(q)||q<0||materials[item].unit==='each'&&!Number.isInteger(q))throw Error('Invalid inbound delivery; whole items require integer quantities.');let left=q;for(const s of stores.filter(s=>s.building===receiving&&s.item===item)){const n=Math.min(left,FactoryEngine.storageCap(s,materials)-balance(s,item));change(s,item,n);if(n>EPS)record('receipt',0,{storage:s.id,item,amount:n});add(totals.incoming,item,n);left-=n}if(left>EPS)diagnostics.add(materials[item].title+': inbound quantity exceeds receiving storage; excess not booked.')}
  for(let i=0;i<all.length;i++){request(all[i],0);if(i%100===0)onProgress({phase:'pre-shift',completed:i,total:all.length})}
  const operatorPaths=[];for(const m of all){if(specs[m.type].support)continue;const path=geo.approach(m,'walker');m.operatorAccess=!!path;if(!path){diagnostics.add(specs[m.type].name+' #'+m.number+': operators have no walkable access.');continue}const duration=path.length*2;operatorPaths.push({m,path,duration});prepEnd=Math.max(prepEnd,duration+m.crew.length*2)}
  // Stagger service crews toward production start rather than paying them to
  // arrive at the beginning of an unrelated long warehouse staging phase.
  const serviceEnd=Math.max(0,...service.map(s=>s.end)),serviceOffset=Math.max(0,prepEnd-serviceEnd);
  if(serviceOffset&&service.length){for(const s of service)for(const k of ['walkStart','walkEnd','start','end'])s[k]+=serviceOffset;for(const e of events)if(e.type==='maintenance-start'||e.type==='maintenance-end')e.time+=serviceOffset;const scheduled=queue.a.splice(0);for(const e of scheduled){if(e.type==='service')e.time+=serviceOffset;queue.push(e)}}
  applyEvents(prepEnd);phase='shift';const shiftStart=prepEnd;shiftEnd=shiftStart+config.hours*3600;
  for(const m of all){const s=specs[m.type],d=details[m.id],st=stage[m.type];d.capacity=m.operatorAccess===false?0:FactoryEngine.effectiveRate(m,specs,upgrades)*config.hours/9;st.possible+=d.capacity;st.rated+=FactoryEngine.ratedRate(m,specs,upgrades)*config.hours/9;for(const [item,q]of Object.entries(s.inputs))d.inputNeed[item]=q*d.capacity;
   // Resume real unfinished work; already-reserved inputs are not consumed twice.
   if(state.work[m.id]){const w=state.work[m.id];w.resumed=true;if(d.capacity<EPS){pausedWork.add(m.id);continue}w.started=shiftStart;w.finish=shiftStart+w.remaining;event(w.finish,'complete',{id:m.id})}}
  for(const type of Object.keys(specs))stage[type]??={rated:0,possible:0,actual:0,machines:0};
  const order=FactoryEngine.topological(specs),sorted=all.slice().sort((a,b)=>order.indexOf(a.type)-order.indexOf(b.type)||a.id.localeCompare(b.id));
  for(let t=shiftStart;t<shiftEnd;t=Math.min(shiftEnd,t+config.tickSeconds)){
   applyEvents(t);if(Math.round((t-shiftStart)/config.tickSeconds)%30===0){traffic.prune(t);onProgress({phase:'production',completed:t-shiftStart,total:config.hours*3600,preShiftHours:shiftStart/3600})}
   // Clear downstream finished/WIP buffers before requesting upstream refills.
   for(const m of sorted)if(Object.hasOwn(specs[m.type].outputs,'shipped')){let q=remaining(m,'shipped'),tries=0;while(q>EPS&&tries++<10){const n=schedule(m,sink,'shipped',q,t);if(!n)break;q-=n}}
   for(const m of sorted.slice().reverse()){const s=specs[m.type];if(s.support)continue;
    request(m,t);
    if(state.work[m.id])continue;
    const rate=m.operatorAccess===false?0:FactoryEngine.effectiveRate(m,specs,upgrades);if(rate<EPS)continue;
    const duration=9*3600/rate,maxBatches=Math.max(1,Math.ceil(rate*config.bufferMinutes/540));if(Object.entries(s.outputs).some(([k,q])=>{const collected=(pickupBookings[m.id+'|'+k]||[]).filter(p=>p.time>t&&p.time<=t+duration).reduce((n,p)=>n+p.amount,0);return (state.outputs[m.id][k]||0)-collected+q>q*maxBatches+EPS})){details[m.id].blocked++;continue}
    const missing=Object.entries(s.inputs).filter(([k,q])=>(state.inputs[m.id][k]||0)+EPS<q);if(missing.length){for(const [k]of missing)add(details[m.id].shortages,k,1);continue}
    for(const [item,q]of Object.entries(s.inputs)){add(state.inputs[m.id],item,-q);add(totals.consumed,item,q)}state.work[m.id]={inputs:copy(s.inputs),started:t,finish:t+duration,remaining:duration};event(t+duration,'complete',{id:m.id});record('work-start',t,{machine:m.id,finish:t+duration});
   }
  }
  applyEvents(shiftEnd);
  // Work-in-progress remains tied to its original inputs between shifts.
  for(const m of all){const starts=events.filter(e=>e.type==='work-start'&&e.machine===m.id),resumed=initialState.work[m.id];let busy=starts.reduce((n,e)=>n+Math.max(0,Math.min(e.finish,shiftEnd)-e.time),0);if(resumed&&!pausedWork.has(m.id))busy+=Math.min(resumed.remaining,config.hours*3600);details[m.id].busySeconds=busy;if(state.work[m.id]&&!pausedWork.has(m.id))state.work[m.id].remaining=Math.max(0,state.work[m.id].finish-shiftEnd);const fraction=busy/(9*3600),condition=Math.max(.05,m.condition-config.wearPerDay*fraction);state.conditions[m.id]=condition;record('condition',shiftEnd,{machine:m.id,condition});for(const w of FactoryEngine.productiveCrew(m,specs,upgrades))if(!specs[m.type].support)add(workHours,w.id,busy/3600)}
  // Skills and assignments remain fixed. Work hours are day-level accounting,
  // not an employee progression system.
  const people=[];for(const {m,path,duration}of operatorPaths)for(const [i,w]of m.crew.entries())people.push({id:w.id,role:w.role,level:initialState.employees[w.id]?.level??w.level,machine:m.id,building:m.building,path:internPath(path),start:Math.max(0,shiftStart-duration-i*2),end:shiftStart-i*2});
  for(const s of service)people.push({id:s.worker,role:'shiftSupport',level:initialState.employees[s.worker]?.level??2,machine:s.machine,building:s.building,path:s.path,start:s.walkStart,end:s.walkEnd});
  const closing=inventoryTotals(),transit={};for(const t of trips)if(t.pickup<=shiftEnd&&t.drop>shiftEnd)add(transit,t.item,t.amount);
  // Inputs in unfinished work remain inventory, rather than disappearing as a
  // completed transformation. Reverse consumption for those still in process.
  for(const [id,w]of Object.entries(state.work))if(!w.resumed)for(const [k,q]of Object.entries(w.inputs))add(totals.consumed,k,-q);
  for(const item of Object.keys(materials)){const row={item,opening:totals.opening[item]||0,incoming:totals.incoming[item]||0,produced:totals.produced[item]||0,consumed:totals.consumed[item]||0,shipped:totals.shipped[item]||0,closing:closing[item]||0,inTransit:transit[item]||0};row.error=row.opening+row.incoming+row.produced-row.consumed-row.shipped-row.closing-row.inTransit;ledger.push(row)}
  const imbalance=ledger.filter(r=>Math.abs(r.error)>1e-5);if(imbalance.length)throw Error('Inventory conservation failed: '+imbalance.map(r=>r.item+' '+r.error).join(', '));
  for(const m of all){const excess=m.crew.length-FactoryEngine.crewLimit(m,specs,upgrades);if(excess>0)diagnostics.add(specs[m.type].name+' #'+m.number+': '+excess+' excess assigned workers retained and paid; excluded from productive hours.');if(details[m.id].blocked)diagnostics.add(specs[m.type].name+' #'+m.number+': output buffer blocked.');if(Object.keys(details[m.id].shortages).length)diagnostics.add(specs[m.type].name+' #'+m.number+': waiting for '+Object.keys(details[m.id].shortages).map(k=>materials[k].title).join(', '))}
  const driverFirst=new Map(),techFirst=new Map();for(const t of trips)if(t.driver&&t.start<shiftStart)driverFirst.set(t.driver,Math.min(driverFirst.get(t.driver)??Infinity,t.start));for(const s of service)techFirst.set(s.worker,Math.min(techFirst.get(s.worker)??Infinity,s.walkStart));
  const prepDriverHours=[...driverFirst.values()].reduce((n,t)=>n+(shiftStart-t)/3600,0),prepMaintenanceHours=[...techFirst.values()].reduce((n,t)=>n+(shiftStart-t)/3600,0),vehicleHours=trips.filter(t=>t.kind!=='belt').reduce((n,t)=>n+(t.end-t.start)/3600,0),crew=all.flatMap(m=>m.crew),roster=[...new Map([...crew,...workers].map(w=>[w.id,w])).values()],paidIds=new Set([...crew.map(w=>w.id),...vehicles.map(v=>v.driver),...service.map(s=>s.worker)]),paidRoster=config.payUnassigned?roster:roster.filter(w=>paidIds.has(w.id)),normalHours=paidRoster.length*config.hours,productiveHours=all.reduce((n,m)=>n+details[m.id].busySeconds/3600*FactoryEngine.productiveCrew(m,specs,upgrades).length,0),byRole={},byProcess={};
  for(const w of paidRoster){const row=byRole[w.role||'other']??={people:0,normalHours:0,preShiftHours:0};row.people++;row.normalHours+=config.hours;row.preShiftHours+=driverFirst.has(w.id)?(shiftStart-driverFirst.get(w.id))/3600:techFirst.has(w.id)?(shiftStart-techFirst.get(w.id))/3600:0}
  for(const m of all){const row=byProcess[m.type]??={workers:0,paidHours:0,productiveHours:0};row.workers+=m.crew.length;row.paidHours+=m.crew.length*config.hours;row.productiveHours+=details[m.id].busySeconds/3600*FactoryEngine.productiveCrew(m,specs,upgrades).length}
  const labour={normalShiftHours:normalHours,preShiftLogisticsHours:prepDriverHours,preShiftMaintenanceHours:prepMaintenanceHours,totalPaidHours:normalHours+prepDriverHours+prepMaintenanceHours,productiveMachineHours:productiveHours,vehicleBusyHours:vehicleHours,paidPeople:paidRoster.length,unassignedPaidPeople:paidRoster.filter(w=>!paidIds.has(w.id)).length,byRole,byProcess};
  const weightedHours=paidRoster.length*(Math.min(9,config.hours)+Math.max(0,config.hours-9)*config.overtimeMultiplier),cost={prepLabour:prepDriverHours*config.wage*config.overtimeMultiplier,shiftLabour:weightedHours*config.wage,logisticsLabour:0,maintenanceLabour:prepMaintenanceHours*config.maintenanceWage*config.overtimeMultiplier,parts:service.length*config.partCost,energy:vehicleHours*config.energyPerVehicleHour};cost.total=sum(cost);
  const routes=new Map(),links=new Map();for(const t of trips){if(t.drop>shiftEnd)continue;const path=paths[t.path].slice(t.pickupIndex,t.dropIndex+1);for(const name of geo.names){const cells=path.filter(p=>p[0]===name).map(p=>p.slice(1));if(!cells.length)continue;const id=t.from+'|'+t.to+'|'+t.item+'|'+name;if(!routes.has(id))routes.set(id,{building:name,cells,item:t.item,from:t.from.replace('in:',''),to:t.to.replace('in:',''),rate:0,interbuilding:t.sourceBuilding!==t.targetBuilding});routes.get(id).rate+=t.amount}if(t.sourceBuilding!==t.targetBuilding){const id=t.sourceBuilding+'|'+t.targetBuilding;if(!links.has(id))links.set(id,{from:t.sourceBuilding,to:t.targetBuilding,total:0,items:{}});const link=links.get(id);link.total+=t.amount*materials[t.item].volume;add(link.items,t.item,t.amount)}}
  const cellTraffic=Object.fromEntries(geo.names.map(name=>[name,{}]));for(const r of routes.values())for(const [x,y]of r.cells){const key=x+','+y,row=cellTraffic[r.building][key]??={total:0,items:{}};row.total+=r.rate*materials[r.item].volume;add(row.items,r.item,r.rate)}
  delete state.looseInventoryCredit;
  state.fleetPositions??={};for(const v of vehicles)state.fleetPositions[v.id]={kind:v.kind,parking:v.parking,driver:v.driver};
  state.day++;state.cumulative.shipped+=shipped;state.cumulative.cost+=cost.total;state.history.push({day:state.day,date:config.operatingDate||null,certified:stage.qa?.actual||0,shipped,prepHours:shiftStart/3600,cost:cost.total});if(state.history.length>90)state.history.shift();
  events.sort((a,b)=>a.time-b.time);return {kind:'operating-day',config,initialState,finalState:state,shiftStart,shiftEnd,events,trips,paths,service,vehicles,people,physics,ledger,cost,promotions,labour,prepHours:shiftStart/3600,cellTraffic,traffic:{waitSeconds:traffic.waitSeconds,conflicts:traffic.conflicts},machines,stage,stocks:state.stocks,buffers:state.outputs,details,diagnostics:[...diagnostics],routes:[...routes.values()],links:[...links.values()],dailyOutputs:[stage.qa?.actual||0],hours:config.hours,steps:Math.ceil(config.hours*3600/config.tickSeconds),warmupDays:0,shipped,productionHours:productiveHours,anchors:geo.anchors};
 }
 return {DEFAULTS,VEHICLES,settings,materialPhysics,payload,initial,simulate,validateState,Traffic,geometry};
})();
if(typeof module!=='undefined')module.exports=FactoryDay;
