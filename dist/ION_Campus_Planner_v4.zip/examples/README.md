# Recorded Orinda prototype day

Open the V4 HTML in a fresh browser session with the unchanged register layout. Choose Orinda, click **Load replay**, and select `ION_Orinda_Day_1_replay.json`. Press Play, seek, change speed, or select a building. Loading/replaying does not post inventory, time or spending.

The file is gzip-compressed JSON, decoded by the tool. It records 245 certifications, 195 dispatches and retained leftovers, with zero certified engines at opening. Assumed WIP allocation, service, traffic parameters and wages are stored with the replay. This is a model example, not a measurement of the actual factory. The recorded 247/day reference remains separate. A full workspace with a different layout must be restored separately before loading its matching replay.

Use the compact daily labour/production report and implementation handoff for document updates; the detailed replay is primarily a visual event log. See `docs/VALIDATION_V4.json` for the baseline summary.
